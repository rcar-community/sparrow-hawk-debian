/* SPDX-License-Identifier: GPL-2.0 */
#ifdef __NR_chmod
__NR_chmod,
#endif
__NR_fchmod,
#ifdef __NR_chown
__NR_chown,
__NR_lchown,
#endif
#ifdef __NR_fchown
__NR_fchown,
#endif
__NR_setxattr,
#ifdef __NR_setxattrat
__NR_setxattrat,
#endif
__NR_lsetxattr,
__NR_fsetxattr,
__NR_removexattr,
#ifdef __NR_removexattrat
__NR_removexattrat,
#endif
__NR_lremovexattr,
__NR_fremovexattr,
#ifdef __NR_fchownat
__NR_fchownat,
__NR_fchmodat,
#endif
#ifdef __NR_fchmodat2
__NR_fchmodat2,
#endif
#ifdef __NR_chown32
__NR_chown32,
__NR_fchown32,
__NR_lchown32,
#endif
#ifdef __NR_link
__NR_link,
#endif
#ifdef __NR_linkat
__NR_linkat,
#endif
